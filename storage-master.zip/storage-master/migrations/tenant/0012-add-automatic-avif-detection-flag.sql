alter table storage.buckets add column if not exists avif_autodetection bool default false;
