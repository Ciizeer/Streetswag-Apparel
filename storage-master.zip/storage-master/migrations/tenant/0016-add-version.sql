alter table storage.objects add column if not exists version text default null;
