ALTER TABLE storage.objects
    DROP CONSTRAINT IF EXISTS objects_owner_fkey;