ALTER TABLE tenants ADD COLUMN feature_image_transformation boolean DEFAULT false NOT NULL;
