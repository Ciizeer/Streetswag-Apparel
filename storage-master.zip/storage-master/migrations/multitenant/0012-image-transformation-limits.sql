
ALTER TABLE tenants ADD COLUMN image_transformation_max_resolution int NULL;
