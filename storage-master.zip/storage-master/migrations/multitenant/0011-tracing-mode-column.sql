
ALTER TABLE tenants ADD COLUMN tracing_mode text NOT NULL DEFAULT 'basic';
